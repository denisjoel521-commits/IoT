// Medidor de tiempo de reaccion con sensor ultrasonico + Bluetooth HC-05
// Version FISICA - LCD I2C (4 cables) + envio de resultados a app Android
// Sensores: HC-SR04 (proximidad), LDR (luz ambiente)
// Actuadores: LED rojo, LED verde, buzzer, LCD 16x2 I2C
// Comunicacion: modulo HC-05 por SoftwareSerial (pines D11 RX, D12 TX)
// Integrantes: Denis Montecinos, Martin Artigas

#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <SoftwareSerial.h>

// --- Pines ---
const uint8_t PIN_TRIG   = 9;
const uint8_t PIN_ECHO   = 10;
const uint8_t PIN_LDR    = A0;
const uint8_t PIN_LED_V  = 3;
const uint8_t PIN_LED_R  = 4;
const uint8_t PIN_BUZZER = 7;

// HC-05: conectar TXD del modulo a D11 (RX del Arduino) y RXD del modulo a D12 (TX del Arduino)
// IMPORTANTE: el RXD del HC-05 es de 3.3V. Usa un divisor de tension (resistencias 1k + 2k)
// entre D12 y el RXD del modulo para no danarlo.
SoftwareSerial bluetooth(11, 12); // RX, TX

// --- Parametros del juego ---
const float UMBRAL_CM      = 15.0;
const int   LUZ_MIN        = 200;
const unsigned long TIMEOUT = 25000;
const unsigned long DURACION_VERDE = 3000;

const unsigned long LIMITE_RAPIDO   = 250;
const unsigned long LIMITE_PROMEDIO = 400;

LiquidCrystal_I2C lcd(0x27, 16, 2);

unsigned long mejorTiempo = 0;
unsigned long sumaTiempos = 0;
unsigned int  numIntentos = 0;

void setup() {
  pinMode(PIN_TRIG, OUTPUT);
  pinMode(PIN_ECHO, INPUT);
  pinMode(PIN_LED_V, OUTPUT);
  pinMode(PIN_LED_R, OUTPUT);
  pinMode(PIN_BUZZER, OUTPUT);
  Serial.begin(9600);
  bluetooth.begin(9600);   // velocidad por defecto del HC-05
  randomSeed(analogRead(A1));

  lcd.init();
  lcd.backlight();
  lcd.setCursor(0, 0);
  lcd.print("Test de reaccion");
  lcd.setCursor(0, 1);
  lcd.print("Acerca la mano");
  Serial.println("Acerca la mano al sensor para empezar.");
}

float medirDistancia() {
  digitalWrite(PIN_TRIG, LOW);  delayMicroseconds(2);
  digitalWrite(PIN_TRIG, HIGH); delayMicroseconds(10);
  digitalWrite(PIN_TRIG, LOW);
  unsigned long dur = pulseIn(PIN_ECHO, HIGH, TIMEOUT);
  if (dur == 0) return -1;
  return dur * 0.0343 / 2.0;
}

bool manoDetectada() {
  float d = medirDistancia();
  return (d > 0 && d < UMBRAL_CM);
}

void esperarManoFuera() {
  while (manoDetectada()) delay(30);
}

String clasificar(unsigned long ms) {
  if (ms < LIMITE_RAPIDO)        return "RAPIDO";
  else if (ms < LIMITE_PROMEDIO) return "PROMEDIO";
  else                           return "LENTO";
}

void mostrarResultado(unsigned long ms) {
  numIntentos++;
  sumaTiempos += ms;
  if (mejorTiempo == 0 || ms < mejorTiempo) mejorTiempo = ms;
  unsigned long promedio = sumaTiempos / numIntentos;
  String nivel = clasificar(ms);

  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("Reaccion:");
  lcd.print(ms);
  lcd.print("ms");
  lcd.setCursor(0, 1);
  lcd.print("Nivel: ");
  lcd.print(nivel);

  Serial.print("Reaccion: ");       Serial.print(ms);
  Serial.print(" ms | Nivel: ");    Serial.print(nivel);
  Serial.print(" | Mejor: ");       Serial.print(mejorTiempo);
  Serial.print(" ms | Promedio: "); Serial.print(promedio);
  Serial.println(" ms");

  // --- Envio a la app Android por Bluetooth ---
  // Formato que la app espera: REACCION:<ms>:<nivel>
  bluetooth.print("REACCION:");
  bluetooth.print(ms);
  bluetooth.print(":");
  bluetooth.println(nivel);
}

void loop() {
  // 1) Verificar iluminacion ambiente (LDR)
  int luz = analogRead(PIN_LDR);
  if (luz < LUZ_MIN) {
    lcd.clear();
    lcd.setCursor(0, 0);
    lcd.print("Ambiente oscuro");
    lcd.setCursor(0, 1);
    lcd.print("Enciende la luz");
    digitalWrite(PIN_LED_R, HIGH);
    delay(1500);
    return;
  }

  // 2) Reposo: ROJO encendido, esperar que acerquen y retiren la mano
  digitalWrite(PIN_LED_R, HIGH);
  digitalWrite(PIN_LED_V, LOW);
  while (!manoDetectada()) delay(30);
  esperarManoFuera();

  // 3) Pausa de 2 s tras detectar la mano, luego "Espera al verde"
  delay(2000);
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("Espera al verde");

  // 4) Ventana de 30 s: el verde se prende en un instante aleatorio (seg 1 a 30)
  unsigned long instanteVerde = random(1000, 30000); // ms desde ahora
  unsigned long t0 = millis();
  bool salidaFalsa = false;
  while (millis() - t0 < instanteVerde) {
    if (manoDetectada()) { salidaFalsa = true; break; }
  }

  // Salida en falso: reacciono antes del verde
  if (salidaFalsa) {
    digitalWrite(PIN_LED_R, LOW);
    tone(PIN_BUZZER, 400, 500);   // tono grave de aviso
    lcd.clear();
    lcd.setCursor(0, 0);
    lcd.print("Salida en falso");
    Serial.println("Salida en falso");
    bluetooth.println("REACCION:0:FALSO");   // aviso a la app (no cuenta como medicion)
    for (int i = 0; i < 4; i++) {
      digitalWrite(PIN_LED_R, LOW);  delay(120);
      digitalWrite(PIN_LED_R, HIGH); delay(120);
    }
    esperarManoFuera();
    delay(1000);
    return;
  }

  // 5) Estimulo: se apaga el ROJO, se prende el VERDE, suena el buzzer y arranca la medicion
  digitalWrite(PIN_LED_R, LOW);
  digitalWrite(PIN_LED_V, HIGH);
  tone(PIN_BUZZER, 1200, 80);   // tono agudo breve = estimulo
  unsigned long tEstimulo = millis();
  bool reacciono = false;

  // El verde se mantiene prendido 3 s; mide si la mano llega en ese tiempo
  while (millis() - tEstimulo < DURACION_VERDE) {
    if (manoDetectada()) { reacciono = true; break; }
  }
  unsigned long reaccion = millis() - tEstimulo;
  digitalWrite(PIN_LED_V, LOW);   // el verde se apaga tras reaccionar o tras 3 s

  // 6) Resultado
  if (!reacciono) {
    lcd.clear();
    lcd.setCursor(0, 0);
    lcd.print("Muy lento!");
    lcd.setCursor(0, 1);
    lcd.print("Intenta de nuevo");
    Serial.println("Sin reaccion (timeout)");
    bluetooth.println("REACCION:0:TIMEOUT");
    esperarManoFuera();
    delay(1500);
    return;
  }

  mostrarResultado(reaccion);
  esperarManoFuera();
  delay(2000);
}
