# Reglas ProGuard del proyecto (sin ofuscacion en debug)
