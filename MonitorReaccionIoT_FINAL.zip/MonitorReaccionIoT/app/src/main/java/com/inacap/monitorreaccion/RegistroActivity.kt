package com.inacap.monitorreaccion

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class RegistroActivity : AppCompatActivity() {

    private lateinit var db: DBHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registro)
        db = DBHelper(this)

        val etUsuario = findViewById<EditText>(R.id.etNuevoUsuario)
        val etPass = findViewById<EditText>(R.id.etNuevaPass)
        val etPass2 = findViewById<EditText>(R.id.etConfirmarPass)
        val btnCrear = findViewById<Button>(R.id.btnCrear)

        btnCrear.setOnClickListener {
            val usuario = etUsuario.text.toString().trim()
            val pass = etPass.text.toString()
            val pass2 = etPass2.text.toString()

            if (usuario.isEmpty() || pass.isEmpty()) {
                Toast.makeText(this, "Completa todos los campos", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (pass.length < 4) {
                Toast.makeText(this, "La contrasena debe tener al menos 4 caracteres", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (pass != pass2) {
                Toast.makeText(this, "Las contrasenas no coinciden", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (db.registrarUsuario(usuario, pass)) {
                Toast.makeText(this, "Usuario creado, ya puedes iniciar sesion", Toast.LENGTH_SHORT).show()
                finish()
            } else {
                Toast.makeText(this, "Ese usuario ya existe", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
