package com.inacap.monitorreaccion

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class LoginActivity : AppCompatActivity() {

    private lateinit var db: DBHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        db = DBHelper(this)

        val etUsuario = findViewById<EditText>(R.id.etUsuario)
        val etPass = findViewById<EditText>(R.id.etPass)
        val btnLogin = findViewById<Button>(R.id.btnLogin)
        val tvRegistro = findViewById<TextView>(R.id.tvIrRegistro)

        btnLogin.setOnClickListener {
            val usuario = etUsuario.text.toString().trim()
            val pass = etPass.text.toString()

            if (usuario.isEmpty() || pass.isEmpty()) {
                Toast.makeText(this, "Completa usuario y contrasena", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (db.validarLogin(usuario, pass)) {
                // Pasamos el usuario a la siguiente pantalla
                val intent = Intent(this, MonitorActivity::class.java)
                intent.putExtra("usuario", usuario)
                startActivity(intent)
            } else {
                Toast.makeText(this, "Credenciales incorrectas", Toast.LENGTH_SHORT).show()
            }
        }

        tvRegistro.setOnClickListener {
            startActivity(Intent(this, RegistroActivity::class.java))
        }
    }
}
