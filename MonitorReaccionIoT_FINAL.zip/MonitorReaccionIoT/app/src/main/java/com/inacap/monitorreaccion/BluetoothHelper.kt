package com.inacap.monitorreaccion

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID

/**
 * Maneja conexiones RFCOMM de salida (cliente).
 *  - Modo HC-05: usa el UUID estandar de Serial Port Profile (Arduino).
 *  - Modo Android<->Android: usa UUID_APP propio para conectar a otro telefono
 *    que esta corriendo esta misma app en modo receptor (servidor).
 */
class BluetoothHelper {

    companion object {
        // UUID estandar SPP para modulos HC-05 / HC-06
        val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

        // UUID propio de la app para la comunicacion Android <-> Android
        val UUID_APP: UUID = UUID.fromString("f47ac10b-58cc-4372-a567-0e02b2c3d479")
    }

    private var socket: BluetoothSocket? = null
    private var inputStream: InputStream? = null
    private var outputStream: OutputStream? = null

    @Volatile
    private var escuchando = false

    /** Lista los dispositivos ya emparejados (HC-05 u otro Android emparejado). */
    @SuppressLint("MissingPermission")
    fun dispositivosEmparejados(): List<BluetoothDevice> {
        val adapter = BluetoothAdapter.getDefaultAdapter() ?: return emptyList()
        return adapter.bondedDevices?.toList() ?: emptyList()
    }

    /**
     * Conecta al dispositivo elegido usando el UUID indicado.
     *  - SPP_UUID para el HC-05.
     *  - UUID_APP para otro Android.
     */
    @SuppressLint("MissingPermission")
    fun conectar(device: BluetoothDevice, uuid: UUID = SPP_UUID): Boolean {
        return try {
            val adapter = BluetoothAdapter.getDefaultAdapter()
            adapter?.cancelDiscovery()
            socket = device.createRfcommSocketToServiceRecord(uuid)
            socket?.connect()
            inputStream = socket?.inputStream
            outputStream = socket?.outputStream
            true
        } catch (e: Exception) {
            cerrar()
            false
        }
    }

    /**
     * Escucha linea por linea lo que llega por el socket.
     * HC-05 envia por ejemplo: "REACCION:287:RAPIDO\n"
     * Otro Android reenvia el mismo formato.
     */
    fun escuchar(onLinea: (String) -> Unit) {
        escuchando = true
        Thread {
            val buffer = ByteArray(1024)
            val sb = StringBuilder()
            val input = inputStream ?: return@Thread
            while (escuchando) {
                try {
                    val bytes = input.read(buffer)
                    if (bytes > 0) {
                        val texto = String(buffer, 0, bytes)
                        sb.append(texto)
                        var idx = sb.indexOf("\n")
                        while (idx != -1) {
                            val linea = sb.substring(0, idx).trim()
                            sb.delete(0, idx + 1)
                            if (linea.isNotEmpty()) onLinea(linea)
                            idx = sb.indexOf("\n")
                        }
                    }
                } catch (e: Exception) {
                    break
                }
            }
        }.start()
    }

    /** Envia una linea de texto al otro extremo (usado para reenviar al segundo Android). */
    fun enviar(linea: String): Boolean {
        return try {
            outputStream?.write((linea.trimEnd() + "\n").toByteArray())
            outputStream?.flush()
            true
        } catch (e: Exception) {
            false
        }
    }

    fun cerrar() {
        escuchando = false
        try { inputStream?.close() } catch (_: Exception) {}
        try { outputStream?.close() } catch (_: Exception) {}
        try { socket?.close() } catch (_: Exception) {}
        inputStream = null
        outputStream = null
        socket = null
    }

    fun estaConectado(): Boolean = socket?.isConnected == true
}
