package com.inacap.monitorreaccion

import android.Manifest
import android.bluetooth.BluetoothDevice
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Pantalla principal: conecta al HC-05 y muestra en vivo los tiempos de reaccion
 * que manda el Arduino. Cada medicion recibida se guarda en SQLite.
 */
class MonitorActivity : AppCompatActivity() {

    private lateinit var db: DBHelper
    private val bt = BluetoothHelper()
    private lateinit var usuario: String

    private lateinit var tvEstado: TextView
    private lateinit var tvTiempo: TextView
    private lateinit var tvNivel: TextView

    private val PERM_CODE = 100

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_monitor)

        db = DBHelper(this)
        usuario = intent.getStringExtra("usuario") ?: "invitado"

        tvEstado = findViewById(R.id.tvEstado)
        tvTiempo = findViewById(R.id.tvTiempo)
        tvNivel = findViewById(R.id.tvNivel)
        val tvBienvenida = findViewById<TextView>(R.id.tvBienvenida)
        val btnConectar = findViewById<Button>(R.id.btnConectar)
        val btnHistorial = findViewById<Button>(R.id.btnHistorial)

        tvBienvenida.text = "Hola, $usuario"

        btnConectar.setOnClickListener {
            if (tienePermisos()) mostrarDispositivos() else pedirPermisos()
        }

        btnHistorial.setOnClickListener {
            val intent = Intent(this, HistorialActivity::class.java)
            intent.putExtra("usuario", usuario)
            startActivity(intent)
        }

        val btnCompartir = findViewById<Button>(R.id.btnCompartir)
        btnCompartir.setOnClickListener {
            val intent = Intent(this, CompartirActivity::class.java)
            intent.putExtra("usuario", usuario)
            startActivity(intent)
        }
    }

    private fun tienePermisos(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) ==
                PackageManager.PERMISSION_GRANTED
        } else {
            ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) ==
                PackageManager.PERMISSION_GRANTED
        }
    }

    private fun pedirPermisos() {
        val permisos = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN)
        } else {
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        ActivityCompat.requestPermissions(this, permisos, PERM_CODE)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERM_CODE && grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            mostrarDispositivos()
        } else {
            Toast.makeText(this, "Se necesitan permisos de Bluetooth", Toast.LENGTH_SHORT).show()
        }
    }

    private fun mostrarDispositivos() {
        val dispositivos = bt.dispositivosEmparejados()
        if (dispositivos.isEmpty()) {
            Toast.makeText(this, "Empareja primero el HC-05 desde Ajustes de Android", Toast.LENGTH_LONG).show()
            return
        }

        val nombres = dispositivos.map { d ->
            try { "${d.name}\n${d.address}" } catch (e: SecurityException) { d.address }
        }
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, nombres)

        AlertDialog.Builder(this)
            .setTitle("Elige el HC-05")
            .setAdapter(adapter) { _, pos -> conectar(dispositivos[pos]) }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun conectar(device: BluetoothDevice) {
        tvEstado.text = "Conectando..."
        Thread {
            val ok = bt.conectar(device)
            runOnUiThread {
                if (ok) {
                    tvEstado.text = "Conectado"
                    escuchar()
                } else {
                    tvEstado.text = "No se pudo conectar"
                    Toast.makeText(this, "Error de conexion. Revisa que el HC-05 este encendido.", Toast.LENGTH_SHORT).show()
                }
            }
        }.start()
    }

    private fun escuchar() {
        bt.escuchar { linea ->
            // Formato esperado del Arduino: "REACCION:287:RAPIDO"
            if (linea.startsWith("REACCION:")) {
                val partes = linea.split(":")
                if (partes.size >= 3) {
                    val tiempo = partes[1].toIntOrNull() ?: return@escuchar
                    val nivel = partes[2]

                    // FALSO / TIMEOUT: solo se avisan, no son mediciones validas
                    if (nivel == "FALSO" || nivel == "TIMEOUT") {
                        runOnUiThread {
                            tvTiempo.text = "--"
                            tvNivel.text = if (nivel == "FALSO") "Salida en falso" else "Muy lento"
                        }
                        return@escuchar
                    }

                    val fecha = SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault()).format(Date())
                    db.guardarMedicion(usuario, tiempo, nivel, fecha)

                    runOnUiThread {
                        tvTiempo.text = "$tiempo ms"
                        tvNivel.text = nivel
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        bt.cerrar()
    }
}
