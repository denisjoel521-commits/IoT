package com.inacap.monitorreaccion

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.security.MessageDigest

/**
 * Base de datos local SQLite.
 * Tabla usuarios: login local (ISO 27400 -> contrasena guardada como hash SHA-256, nunca en claro).
 * Tabla mediciones: historial de tiempos de reaccion recibidos por Bluetooth, asociados al usuario.
 */
class DBHelper(context: Context) :
    SQLiteOpenHelper(context, "monitor_reaccion.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE usuarios (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                usuario TEXT UNIQUE NOT NULL,
                pass_hash TEXT NOT NULL
            )
            """.trimIndent()
        )
        db.execSQL(
            """
            CREATE TABLE mediciones (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                usuario TEXT NOT NULL,
                tiempo_ms INTEGER NOT NULL,
                nivel TEXT NOT NULL,
                fecha TEXT NOT NULL
            )
            """.trimIndent()
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldV: Int, newV: Int) {
        db.execSQL("DROP TABLE IF EXISTS usuarios")
        db.execSQL("DROP TABLE IF EXISTS mediciones")
        onCreate(db)
    }

    // --- Seguridad: hash de la contrasena (ISO 27400, cifrado de credenciales) ---
    private fun hash(texto: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(texto.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }

    // --- Usuarios ---
    fun registrarUsuario(usuario: String, pass: String): Boolean {
        val db = writableDatabase
        return try {
            val valores = ContentValues().apply {
                put("usuario", usuario.trim())
                put("pass_hash", hash(pass))
            }
            val id = db.insert("usuarios", null, valores)
            id != -1L
        } catch (e: Exception) {
            false
        }
    }

    fun validarLogin(usuario: String, pass: String): Boolean {
        val db = readableDatabase
        val cursor = db.rawQuery(
            "SELECT id FROM usuarios WHERE usuario = ? AND pass_hash = ?",
            arrayOf(usuario.trim(), hash(pass))
        )
        val existe = cursor.count > 0
        cursor.close()
        return existe
    }

    // --- Mediciones ---
    fun guardarMedicion(usuario: String, tiempoMs: Int, nivel: String, fecha: String) {
        val db = writableDatabase
        val valores = ContentValues().apply {
            put("usuario", usuario)
            put("tiempo_ms", tiempoMs)
            put("nivel", nivel)
            put("fecha", fecha)
        }
        db.insert("mediciones", null, valores)
    }

    fun obtenerHistorial(usuario: String): List<Medicion> {
        val lista = mutableListOf<Medicion>()
        val db = readableDatabase
        val cursor = db.rawQuery(
            "SELECT tiempo_ms, nivel, fecha FROM mediciones WHERE usuario = ? ORDER BY id DESC",
            arrayOf(usuario)
        )
        while (cursor.moveToNext()) {
            lista.add(
                Medicion(
                    tiempoMs = cursor.getInt(0),
                    nivel = cursor.getString(1),
                    fecha = cursor.getString(2)
                )
            )
        }
        cursor.close()
        return lista
    }
}

data class Medicion(val tiempoMs: Int, val nivel: String, val fecha: String)
