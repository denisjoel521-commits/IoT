package com.inacap.monitorreaccion

import android.Manifest
import android.bluetooth.BluetoothDevice
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Interconexion Android <-> Android por Bluetooth (criterio 2.1.4).
 *
 *  EMISOR:   se conecta al HC-05 (Arduino), recibe las mediciones de reaccion
 *            y las REENVIA al otro Android.
 *  RECEPTOR: queda a la espera, recibe las mediciones del otro Android,
 *            las muestra en pantalla y las guarda en SQLite.
 *
 * Asi quedan dos telefonos con la misma app comunicandose de forma inalambrica.
 */
class CompartirActivity : AppCompatActivity() {

    private lateinit var db: DBHelper
    private lateinit var usuario: String

    private val btCliente = BluetoothHelper()   // conexion con HC-05 y/o envio
    private val btServidor = BluetoothServerHelper()

    private lateinit var tvEstado: TextView
    private lateinit var tvDato: TextView

    private val PERM_CODE = 200

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_compartir)

        db = DBHelper(this)
        usuario = intent.getStringExtra("usuario") ?: "invitado"

        tvEstado = findViewById(R.id.tvEstadoCompartir)
        tvDato = findViewById(R.id.tvDatoCompartir)
        val btnEmisor = findViewById<Button>(R.id.btnEmisor)
        val btnReceptor = findViewById<Button>(R.id.btnReceptor)

        btnEmisor.setOnClickListener {
            if (tienePermisos()) iniciarEmisor() else pedirPermisos()
        }
        btnReceptor.setOnClickListener {
            if (tienePermisos()) iniciarReceptor() else pedirPermisos()
        }
    }

    // ---------------- EMISOR ----------------
    // Paso 1: conectar al HC-05. Paso 2: conectar al otro Android. Paso 3: reenviar.
    private fun iniciarEmisor() {
        val dispositivos = btCliente.dispositivosEmparejados()
        if (dispositivos.isEmpty()) {
            Toast.makeText(this, "No hay dispositivos emparejados", Toast.LENGTH_LONG).show()
            return
        }
        val nombres = dispositivos.map { d ->
            try { "${d.name}\n${d.address}" } catch (e: SecurityException) { d.address }
        }
        AlertDialog.Builder(this)
            .setTitle("Paso 1: elige el HC-05 (Arduino)")
            .setAdapter(ArrayAdapter(this, android.R.layout.simple_list_item_1, nombres)) { _, pos ->
                conectarArduinoYLuegoAndroid(dispositivos, dispositivos[pos])
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun conectarArduinoYLuegoAndroid(todos: List<BluetoothDevice>, arduino: BluetoothDevice) {
        tvEstado.text = "Conectando al HC-05..."
        Thread {
            val okArduino = btCliente.conectar(arduino, BluetoothHelper.SPP_UUID)
            runOnUiThread {
                if (!okArduino) {
                    tvEstado.text = "No se pudo conectar al HC-05"
                    return@runOnUiThread
                }
                // Ahora elegir el otro Android (receptor)
                val otros = todos.filter { it.address != arduino.address }
                val nombres = otros.map { d ->
                    try { "${d.name}\n${d.address}" } catch (e: SecurityException) { d.address }
                }
                AlertDialog.Builder(this)
                    .setTitle("Paso 2: elige el otro telefono (receptor)")
                    .setAdapter(ArrayAdapter(this, android.R.layout.simple_list_item_1, nombres)) { _, pos ->
                        conectarAlReceptor(otros[pos])
                    }
                    .setNegativeButton("Cancelar", null)
                    .show()
            }
        }.start()
    }

    private fun conectarAlReceptor(receptor: BluetoothDevice) {
        tvEstado.text = "Conectando al otro telefono..."
        Thread {
            // El emisor usa un SEGUNDO helper para el enlace Android-Android.
            val btHaciaAndroid = BluetoothHelper()
            val okAndroid = btHaciaAndroid.conectar(receptor, BluetoothHelper.UUID_APP)
            runOnUiThread {
                if (!okAndroid) {
                    tvEstado.text = "No se pudo conectar al receptor"
                    return@runOnUiThread
                }
                tvEstado.text = "Emisor activo: reenviando al receptor"
                // Escucha el HC-05 y reenvia cada linea al otro Android
                btCliente.escuchar { linea ->
                    btHaciaAndroid.enviar(linea)
                    runOnUiThread { tvDato.text = "Enviado: $linea" }
                }
            }
        }.start()
    }

    // ---------------- RECEPTOR ----------------
    private fun iniciarReceptor() {
        tvEstado.text = "Esperando conexion del otro telefono..."
        btServidor.iniciarServidor(
            onConectado = {
                runOnUiThread { tvEstado.text = "Receptor conectado. Recibiendo datos..." }
            },
            onLinea = { linea ->
                procesarRecibido(linea)
            },
            onError = { msg ->
                runOnUiThread { tvEstado.text = msg }
            }
        )
    }

    private fun procesarRecibido(linea: String) {
        if (linea.startsWith("REACCION:")) {
            val partes = linea.split(":")
            if (partes.size >= 3) {
                val tiempo = partes[1].toIntOrNull() ?: return
                val nivel = partes[2]

                // FALSO / TIMEOUT: solo se avisan, no son mediciones validas
                if (nivel == "FALSO" || nivel == "TIMEOUT") {
                    val msg = if (nivel == "FALSO") "Salida en falso" else "Muy lento"
                    runOnUiThread { tvDato.text = "Recibido: $msg" }
                    return
                }

                val fecha = SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault()).format(Date())
                db.guardarMedicion(usuario, tiempo, nivel, fecha)
                runOnUiThread { tvDato.text = "Recibido: $tiempo ms ($nivel)" }
            }
        }
    }

    // ---------------- Permisos ----------------
    private fun tienePermisos(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) ==
                PackageManager.PERMISSION_GRANTED
        } else {
            ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) ==
                PackageManager.PERMISSION_GRANTED
        }
    }

    private fun pedirPermisos() {
        val permisos = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN)
        } else {
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        ActivityCompat.requestPermissions(this, permisos, PERM_CODE)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERM_CODE && grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Permisos concedidos, pulsa de nuevo", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Se necesitan permisos de Bluetooth", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        btCliente.cerrar()
        btServidor.cerrar()
    }
}
