package com.inacap.monitorreaccion

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/**
 * Muestra el historial de mediciones del usuario desde SQLite.
 */
class HistorialActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_historial)

        val db = DBHelper(this)
        val usuario = intent.getStringExtra("usuario") ?: "invitado"

        val tvTitulo = findViewById<TextView>(R.id.tvTituloHist)
        val tvVacio = findViewById<TextView>(R.id.tvVacio)
        val lista = findViewById<ListView>(R.id.listaHistorial)

        tvTitulo.text = "Historial de $usuario"

        val mediciones = db.obtenerHistorial(usuario)

        if (mediciones.isEmpty()) {
            tvVacio.text = "Aun no hay mediciones registradas"
        } else {
            tvVacio.text = ""
            val filas = mediciones.map { m ->
                "${m.tiempoMs} ms  -  ${m.nivel}\n${m.fecha}"
            }
            lista.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, filas)
        }
    }
}
