package com.inacap.monitorreaccion

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import java.io.InputStream

/**
 * Lado SERVIDOR de la comunicacion Android <-> Android.
 * Un telefono queda a la espera (listenUsingRfcomm...) y el otro Android,
 * usando BluetoothHelper.conectar(device, UUID_APP), se conecta a el.
 *
 * Esto cumple el criterio 2.1.4: interconexion entre dos aplicaciones moviles
 * mediante conexion inalambrica Bluetooth.
 */
class BluetoothServerHelper {

    private var serverSocket: BluetoothServerSocket? = null
    private var socket: BluetoothSocket? = null
    private var inputStream: InputStream? = null

    @Volatile
    private var escuchando = false

    /**
     * Espera a que otro Android se conecte. Es bloqueante, llamar en un hilo aparte.
     * onConectado se dispara cuando llega la conexion.
     * onLinea entrega cada linea recibida ("REACCION:287:RAPIDO").
     */
    @SuppressLint("MissingPermission")
    fun iniciarServidor(
        onConectado: () -> Unit,
        onLinea: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        escuchando = true
        Thread {
            try {
                val adapter = BluetoothAdapter.getDefaultAdapter()
                if (adapter == null) {
                    onError("Bluetooth no disponible")
                    return@Thread
                }
                serverSocket = adapter.listenUsingRfcommWithServiceRecord(
                    "MonitorReaccion", BluetoothHelper.UUID_APP
                )
                // Bloquea hasta que otro Android conecte
                socket = serverSocket?.accept()
                serverSocket?.close()  // ya no aceptamos mas conexiones
                inputStream = socket?.inputStream
                onConectado()
                leerLineas(onLinea)
            } catch (e: Exception) {
                if (escuchando) onError("Error servidor: ${e.message}")
            }
        }.start()
    }

    private fun leerLineas(onLinea: (String) -> Unit) {
        val buffer = ByteArray(1024)
        val sb = StringBuilder()
        val input = inputStream ?: return
        while (escuchando) {
            try {
                val bytes = input.read(buffer)
                if (bytes > 0) {
                    sb.append(String(buffer, 0, bytes))
                    var idx = sb.indexOf("\n")
                    while (idx != -1) {
                        val linea = sb.substring(0, idx).trim()
                        sb.delete(0, idx + 1)
                        if (linea.isNotEmpty()) onLinea(linea)
                        idx = sb.indexOf("\n")
                    }
                }
            } catch (e: Exception) {
                break
            }
        }
    }

    fun cerrar() {
        escuchando = false
        try { inputStream?.close() } catch (_: Exception) {}
        try { socket?.close() } catch (_: Exception) {}
        try { serverSocket?.close() } catch (_: Exception) {}
        inputStream = null
        socket = null
        serverSocket = null
    }
}
