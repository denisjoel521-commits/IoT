# Monitor de Reacción IoT — App Android (Unidad 2, TI3042)

Aplicación móvil Android que recibe por **Bluetooth** los tiempos de reacción medidos por un prototipo **Arduino UNO + HC-05** (continuación del Medidor de Tiempo de Reacción de la Unidad 1), los muestra en vivo y guarda un historial por usuario.

**Asignatura:** TI3042 — Internet de las Cosas
**Autor:** Martín Artigas Urrutia
**Institución:** INACAP

## Funcionalidades

- **Login local con SQLite** — autenticación con usuario y contraseña (contraseña guardada como hash SHA-256, nunca en texto plano).
- **Registro de usuarios** nuevos.
- **Conexión Bluetooth (RFCOMM/SPP)** al módulo HC-05 del Arduino.
- **Monitoreo en vivo** del tiempo de reacción y su nivel (RÁPIDO / PROMEDIO / LENTO).
- **Historial por usuario** persistido en SQLite (tiempo, nivel, fecha).

## Stack técnico

| Área | Tecnología |
|---|---|
| Lenguaje | Kotlin |
| IDE | Android Studio |
| Login y almacenamiento | SQLite (local) |
| Comunicación inalámbrica | Bluetooth clásico (SPP / RFCOMM) con HC-05 |
| minSdk / targetSdk | 21 / 34 |

## Seguridad (ISO 27400)

- **Cifrado de credenciales:** las contraseñas se almacenan con hash SHA-256.
- **Control de acceso:** solo usuarios registrados acceden al monitor y al historial.
- **Emparejamiento Bluetooth con PIN:** el HC-05 exige emparejamiento previo desde Ajustes de Android.

## Protocolo de comunicación

El Arduino envía cada medición por el HC-05 en el formato:

```
REACCION:<tiempo_ms>:<nivel>
```

Ejemplo: `REACCION:287:RAPIDO`

La app lee línea por línea, separa por `:` y guarda el registro.

## Cómo probar

1. Montar el prototipo Arduino según la guía de armado (HC-SR04, LDR, LEDs, buzzer, LCD I2C y HC-05).
2. Cargar `codigo_arduino_bluetooth.ino` en el Arduino.
3. Emparejar el HC-05 desde Ajustes → Bluetooth del teléfono (PIN típico: 1234 o 0000).
4. Abrir la app, registrarse / iniciar sesión.
5. Pulsar **Conectar al HC-05** y elegir el módulo.
6. Jugar en el medidor: cada tiempo aparece en la app y queda en el historial.

## Estructura

```
app/src/main/
├── AndroidManifest.xml
├── java/com/inacap/monitorreaccion/
│   ├── LoginActivity.kt
│   ├── RegistroActivity.kt
│   ├── MonitorActivity.kt
│   ├── HistorialActivity.kt
│   ├── DBHelper.kt
│   └── BluetoothHelper.kt
└── res/layout/ + res/values/
```

## Interconexión Android ↔ Android (criterio 2.1.4)

Además de la conexión con el Arduino (HC-05), la app permite que **dos teléfonos
Android** se comuniquen entre sí por Bluetooth, en la pantalla **"Modo 2 dispositivos"**:

- **EMISOR:** se conecta al HC-05, recibe las mediciones de reacción y las reenvía
  al segundo teléfono.
- **RECEPTOR:** queda a la espera (socket servidor con UUID propio de la app),
  recibe las mediciones del emisor, las muestra y las guarda en SQLite.

Esto cumple el requisito de la guía: una aplicación desplegada en al menos dos
dispositivos Android interactuando mediante conexión inalámbrica.

### Cómo probar en la demo
1. Emparejar ambos teléfonos entre sí (y el emisor también con el HC-05) desde Ajustes de Android.
2. En el teléfono receptor: entrar a "Modo 2 dispositivos" → "Soy RECEPTOR".
3. En el teléfono emisor: "Modo 2 dispositivos" → "Soy EMISOR" → elegir HC-05 → elegir el teléfono receptor.
4. Cada reacción del Arduino aparece en ambos teléfonos.
